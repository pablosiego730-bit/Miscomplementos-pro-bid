require "import"
import "android.os.Environment"
import "android.os.Vibrator"
import "java.io.File"
import "java.io.FileOutputStream"
import "java.io.FileInputStream"
import "java.io.BufferedReader"
import "java.io.InputStreamReader"
import "java.io.OutputStreamWriter"
import "java.net.URL"
import "java.net.HttpURLConnection"
import "com.androlua.LuaDialog"
import "android.widget.*"
import "android.view.*"
import "android.os.Handler"
import "android.graphics.Color"
import "android.view.Gravity"
import "android.content.Intent"
import "android.net.Uri"
import "android.media.MediaPlayer"
import "java.lang.Runnable"
import "android.content.Context"
import "android.widget.ArrayAdapter"
import "java.util.ArrayList"
local GIST_ID = "fa184696674bb9a36dab1d2787f09f82"
local NOMBRE_ARCHIVO_GIST = "file1.txt"
local GITHUB_TOKEN = ""
local SERIES = {}
local INDIVIDUALES = {}
local FILTRO = "todos"
local ctx = service or activity
local function speak(texto)
if service and service.asyncSpeak then
service.asyncSpeak(texto)
end
end
local function toast(msg)
Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
end
local function vibrar()
pcall(function()
local vib = ctx.getSystemService("vibrator")
if vib ~= nil then vib.vibrate(120) end
end)
end
local function mostrarError(titulo, mensaje)
speak(mensaje)
local dlg
local layout = {
LinearLayout, orientation = "vertical", padding = "20dp",
{ TextView, text = mensaje, textColor = "#FFFFFF", textSize = "16sp" },
}
dlg = LuaDialog(ctx)
dlg.setTitle(titulo)
dlg.setView(loadlayout(layout))
dlg.setCancelable(true)
dlg.setPositiveButton("Cerrar", function() dlg.dismiss() end)
dlg.show()
end
local function cerrarComplemento()
if activity then
activity.finish()
elseif service then
service.stopSelf()
end
end
local function setLongClick(view, fn)
view.setOnLongClickListener(luajava.createProxy("android.view.View$OnLongClickListener", {
onLongClick = function(v)
fn()
return true
end
}))
end
local function formatearTiempo(ms)
if not ms or ms < 0 then return "00:00" end
local segTotal = math.floor(ms / 1000)
local min = math.floor(segTotal / 60)
local seg = segTotal % 60
return string.format("%02d:%02d", min, seg)
end
local function obtenerTipoArchivo(url)
local ext = url:match("%.(%w+)$")
if not ext then return "otro" end
ext = ext:lower()
if ext == "mp4" or ext == "mkv" or ext == "3gp" or ext == "webm" or ext == "avi" then
return "video"
elseif ext == "mp3" or ext == "wav" or ext == "ogg" or ext == "m4a" or ext == "aac" or ext == "flac" then
return "audio"
else
return "otro"
end
end
local function textoConTipo(nombre, url)
local tipo = obtenerTipoArchivo(url)
if tipo == "audio" then
return "Audio: " .. nombre
elseif tipo == "video" then
return "Video: " .. nombre
else
return "Archivo: " .. nombre
end
end
local function recortar(s)
return (tostring(s):match("^%s*(.-)%s*$"))
end
local function obtenerTokenGuardado()
local pref = ctx.getSharedPreferences("config_gist_app", Context.MODE_PRIVATE)
return pref.getString("github_token", "")
end
local function guardarTokenLocal(token)
local pref = ctx.getSharedPreferences("config_gist_app", Context.MODE_PRIVATE)
local editor = pref.edit()
editor.putString("github_token", token)
editor.commit()
end
local function obtenerFiltroGuardado()
local pref = ctx.getSharedPreferences("config_gist_app", Context.MODE_PRIVATE)
local f = pref.getString("filtro_archivo", "todos")
if f ~= "carpetas" and f ~= "individuales" then f = "todos" end
return f
end
local function guardarFiltroLocal(filtro)
local pref = ctx.getSharedPreferences("config_gist_app", Context.MODE_PRIVATE)
local editor = pref.edit()
editor.putString("filtro_archivo", filtro)
editor.commit()
end
local solicitarTokenDialogo, iniciarFlujoPrincipal, mostrarMenuPrincipal, mostrarSerie
solicitarTokenDialogo = function(esEdicionManual, pantallaAnterior)
local tokenDlg
local dialogLayout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", padding = "16dp", background = "#0D0D1A",
{ TextView, text = "Configurar token", textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingBottom = "12dp" },
{ TextView, text = "Ingresa tu Personal Access Token de GitHub (con permisos de 'gist') para sincronizar y guardar:", textColor = "#AAAAAA", textSize = "14sp", layout_marginBottom = "10dp" },
{ EditText, id = "etTokenInput", hint = "ghp_xxxxxxxxxxxx", text = GITHUB_TOKEN, textColor = "#FFFFFF", hintTextColor = "#666666", background = "#1E1E2E", layout_marginBottom = "16dp" },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "right",
{ Button, text = "Cancelar", textColor = "#FFFFFF", background = "#6B1A1A", layout_marginRight = "8dp",
onClick = function()
vibrar()
tokenDlg.dismiss()
if pantallaAnterior then
pantallaAnterior.show()
elseif not esEdicionManual then
cerrarComplemento()
end
end },
{ Button, text = "Guardar", textColor = "#FFFFFF", background = "#107C41",
onClick = function()
vibrar()
local valorIngresado = recortar(etTokenInput.getText())
if valorIngresado == "" then
toast("Debes ingresar un token válido")
speak("Debes ingresar un token válido")
return
end
guardarTokenLocal(valorIngresado)
GITHUB_TOKEN = valorIngresado
toast("Token guardado correctamente")
speak("Token guardado")
tokenDlg.dismiss()
if pantallaAnterior then
pantallaAnterior.show()
elseif not esEdicionManual then
iniciarFlujoPrincipal()
end
end }
}
}
tokenDlg = LuaDialog(ctx)
tokenDlg.setView(loadlayout(dialogLayout))
tokenDlg.setCancelable(false)
tokenDlg.show()
speak("Ingresa tu token de GitHub")
end
local function reproducirVideoInterno(listaCapitulos, indiceInicial)
local indiceActual = indiceInicial
local handlerVideo = Handler()
local runnableVideo = nil
local videoDlg = nil
local isPrepared = false
local videoLayout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#000000",
{ TextView, id = "tvTituloVid", text = "", textSize = "18sp", textColor = "#FFFFFF", gravity = "center", paddingTop = "12dp", paddingBottom = "8dp", background = "#1A1A2E" },
{ VideoView, id = "videoViewChavo", layout_width = "match_parent", layout_height = "0dp", layout_weight = "1" },
{ TextView, id = "tvTiempoVid", text = "00:00 / 00:00", textSize = "14sp", textColor = "#AAAAAA", gravity = "center", paddingTop = "4dp", paddingBottom = "4dp" },
{ SeekBar, id = "sbProgresoVid", layout_width = "match_parent", layout_marginBottom = "12dp" },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "center", layout_marginBottom = "12dp",
{ Button, id = "btnAnteriorVid", text = "anterior", textSize = "15sp", textColor = "#FFFFFF", background = "#1E1E2E", layout_width = "100dp", layout_marginRight = "8dp" },
{ Button, id = "btnPlayPausaVid", text = "Cargando...", textSize = "15sp", textColor = "#FFFFFF", background = "#0F52BA", layout_width = "110dp" },
{ Button, id = "btnSiguienteVid", text = "siguiente", textSize = "15sp", textColor = "#FFFFFF", background = "#1E1E2E", layout_width = "100dp", layout_marginLeft = "8dp" },
},
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "center", paddingBottom = "12dp",
{ Button, id = "btnVolverVid", text = "Volver", textSize = "15sp", textColor = "#FFFFFF", background = "#3D3D6B", layout_width = "match_parent", layout_marginLeft = "16dp", layout_marginRight = "16dp" }
}
}
videoDlg = LuaDialog(ctx)
videoDlg.setView(loadlayout(videoLayout))
videoDlg.setCancelable(false)
local function cargarVideo(idx)
pcall(function()
isPrepared = false
local cap = listaCapitulos[idx]
tvTituloVid.setText(cap.nombre)
tvTiempoVid.setText("00:00 / 00:00")
btnPlayPausaVid.setText("Cargando...")
speak("Cargando: " .. cap.nombre)
toast("Cargando: " .. cap.nombre)
local headers = luajava.newInstance("java.util.HashMap")
headers.put("User-Agent", "Mozilla/5.0 (Android)")
videoViewChavo.setVideoURI(Uri.parse(cap.githubUrl), headers)
videoViewChavo.start()
end)
end
runnableVideo = Runnable({
run = function()
pcall(function()
if videoViewChavo and videoViewChavo.isPlaying() then
local pos = videoViewChavo.getCurrentPosition()
local dur = videoViewChavo.getDuration()
sbProgresoVid.setProgress(pos)
tvTiempoVid.setText(formatearTiempo(pos) .. " / " .. formatearTiempo(dur))
handlerVideo.postDelayed(runnableVideo, 500)
end
end)
end
})
videoViewChavo.setOnPreparedListener(luajava.createProxy("android.media.MediaPlayer$OnPreparedListener", {
onPrepared = function(mPlayer)
pcall(function()
isPrepared = true
local dur = mPlayer.getDuration()
sbProgresoVid.setMax(dur)
btnPlayPausaVid.setText("Pausar")
speak("Reproduciendo video")
handlerVideo.post(runnableVideo)
end)
end
}))
videoViewChavo.setOnCompletionListener(luajava.createProxy("android.media.MediaPlayer$OnCompletionListener", {
onCompletion = function(mPlayer)
pcall(function()
if indiceActual < #listaCapitulos then
indiceActual = indiceActual + 1
cargarVideo(indiceActual)
else
btnPlayPausaVid.setText("Reproducir")
speak("Video finalizado")
end
end)
end
}))
videoViewChavo.setOnErrorListener(luajava.createProxy("android.media.MediaPlayer$OnErrorListener", {
onError = function(mPlayer, what, extra)
pcall(function()
toast("Error al reproducir el video")
speak("Error al reproducir el video")
btnPlayPausaVid.setText("Reproducir")
end)
return true
end
}))
sbProgresoVid.setOnSeekBarChangeListener(luajava.createProxy("android.widget.SeekBar$OnSeekBarChangeListener", {
onProgressChanged = function(sb, progress, fromUser)
if fromUser and isPrepared then
videoViewChavo.seekTo(progress)
tvTiempoVid.setText(formatearTiempo(progress) .. " / " .. formatearTiempo(videoViewChavo.getDuration()))
end
end,
onStartTrackingTouch = function(sb) end,
onStopTrackingTouch = function(sb) end
}))
btnPlayPausaVid.onClick = function()
vibrar()
pcall(function()
if not isPrepared then return end
if videoViewChavo.isPlaying() then
videoViewChavo.pause()
btnPlayPausaVid.setText("Reproducir")
else
videoViewChavo.start()
btnPlayPausaVid.setText("Pausar")
handlerVideo.post(runnableVideo)
end
end)
end
btnAnteriorVid.onClick = function()
vibrar()
if indiceActual > 1 then
indiceActual = indiceActual - 1
cargarVideo(indiceActual)
else
toast("Primer video")
end
end
btnSiguienteVid.onClick = function()
vibrar()
if indiceActual < #listaCapitulos then
indiceActual = indiceActual + 1
cargarVideo(indiceActual)
else
toast("Último video")
end
end
local function cerrarVideoInterno()
vibrar()
pcall(function()
if runnableVideo then handlerVideo.removeCallbacks(runnableVideo) end
if videoViewChavo then videoViewChavo.stopPlayback() end
end)
videoDlg.dismiss()
end
btnVolverVid.onClick = function()
cerrarVideoInterno()
end
videoDlg.show()
cargarVideo(indiceActual)
end
local function reproducirAudioConControles(listaCapitulos, indiceInicial)
local indiceActual = indiceInicial
local mp = MediaPlayer()
local handler = Handler()
local runnableActualizar = nil
local playerDlg = nil
local audioLayout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#0D0D1A", padding = "16dp",
{ TextView, id = "tvTituloAudio", text = "", textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingTop = "10dp", paddingBottom = "20dp" },
{ TextView, id = "tvTiempoAudio", text = "00:00 / 00:00", textSize = "14sp", textColor = "#8888AA", gravity = "center", layout_marginBottom = "8dp" },
{ SeekBar, id = "sbProgresoAudio", layout_width = "match_parent", layout_marginBottom = "24dp" },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "center", layout_marginBottom = "24dp",
{ Button, id = "btnAnterior", text = "anterior", textSize = "15sp", textColor = "#FFFFFF", background = "#1E1E2E", layout_width = "100dp", layout_marginRight = "8dp" },
{ Button, id = "btnPlayPausa", text = "Pausa", textSize = "15sp", textColor = "#FFFFFF", background = "#0F52BA", layout_width = "110dp" },
{ Button, id = "btnSiguiente", text = "siguiente", textSize = "15sp", textColor = "#FFFFFF", background = "#1E1E2E", layout_width = "100dp", layout_marginLeft = "8dp" },
},
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "center",
{ Button, id = "btnVolverAudio", text = "Volver", textSize = "15sp", textColor = "#FFFFFF", background = "#3D3D6B", layout_width = "match_parent" }
}
}
playerDlg = LuaDialog(ctx)
playerDlg.setView(loadlayout(audioLayout))
playerDlg.setCancelable(false)
local function cargarTrack(idx)
pcall(function()
if mp.isPlaying() then mp.stop() end
mp.reset()
local cap = listaCapitulos[idx]
tvTituloAudio.setText(cap.nombre)
tvTiempoAudio.setText("00:00 / 00:00")
btnPlayPausa.setText("Cargando...")
speak("Reproduciendo: " .. cap.nombre)
local headers = luajava.newInstance("java.util.HashMap")
headers.put("User-Agent", "Mozilla/5.0 (Android)")
mp.setDataSource(ctx, Uri.parse(cap.githubUrl), headers)
mp.prepareAsync()
end)
end
runnableActualizar = Runnable({
run = function()
pcall(function()
if mp and mp.isPlaying() then
local pos = mp.getCurrentPosition()
local dur = mp.getDuration()
sbProgresoAudio.setProgress(pos)
tvTiempoAudio.setText(formatearTiempo(pos) .. " / " .. formatearTiempo(dur))
handler.postDelayed(runnableActualizar, 500)
end
end)
end
})
mp.setOnPreparedListener(luajava.createProxy("android.media.MediaPlayer$OnPreparedListener", {
onPrepared = function(mPlayer)
pcall(function()
local dur = mPlayer.getDuration()
sbProgresoAudio.setMax(dur)
mPlayer.start()
btnPlayPausa.setText("Pausar")
handler.post(runnableActualizar)
end)
end
}))
mp.setOnCompletionListener(luajava.createProxy("android.media.MediaPlayer$OnCompletionListener", {
onCompletion = function(mPlayer)
pcall(function()
if indiceActual < #listaCapitulos then
indiceActual = indiceActual + 1
cargarTrack(indiceActual)
else
btnPlayPausa.setText("Reproducir")
sbProgresoAudio.setProgress(sbProgresoAudio.getMax())
end
end)
end
}))
sbProgresoAudio.setOnSeekBarChangeListener(luajava.createProxy("android.widget.SeekBar$OnSeekBarChangeListener", {
onProgressChanged = function(sb, progress, fromUser)
if fromUser and mp then
mp.seekTo(progress)
tvTiempoAudio.setText(formatearTiempo(progress) .. " / " .. formatearTiempo(mp.getDuration()))
end
end,
onStartTrackingTouch = function(sb) end,
onStopTrackingTouch = function(sb) end
}))
btnPlayPausa.onClick = function()
vibrar()
pcall(function()
if mp.isPlaying() then
mp.pause()
btnPlayPausa.setText("Reproducir")
else
mp.start()
btnPlayPausa.setText("Pausar")
handler.post(runnableActualizar)
end
end)
end
btnAnterior.onClick = function()
vibrar()
if indiceActual > 1 then
indiceActual = indiceActual - 1
cargarTrack(indiceActual)
else
toast("Primera pista")
end
end
btnSiguiente.onClick = function()
vibrar()
if indiceActual < #listaCapitulos then
indiceActual = indiceActual + 1
cargarTrack(indiceActual)
else
toast("Última pista")
end
end
local function detenerYSalir()
vibrar()
pcall(function()
if runnableActualizar then handler.removeCallbacks(runnableActualizar) end
if mp then
if mp.isPlaying() then mp.stop() end
mp.release()
end
end)
playerDlg.dismiss()
end
btnVolverAudio.onClick = function()
detenerYSalir()
end
playerDlg.show()
cargarTrack(indiceActual)
end
local function descargarArchivoLocal(nombreMostrar, urlGithub)
speak("Iniciando descarga")
toast("Descargando: " .. nombreMostrar)
local logica_descarga = function(urlArg)
local ok, res = pcall(function()
local u = URL(urlArg)
local conn = u.openConnection()
conn.setInstanceFollowRedirects(true)
conn.setRequestProperty("User-Agent", "Mozilla/5.0")
conn.connect()
local code = conn.getResponseCode()
if code == 301 or code == 302 or code == 303 or code == 307 or code == 308 then
local redirectUrl = conn.getHeaderField("Location")
if redirectUrl then
u = URL(redirectUrl)
conn = u.openConnection()
conn.setRequestProperty("User-Agent", "Mozilla/5.0")
conn.connect()
end
end
local finalPath = u.getPath()
local nombreOriginal = finalPath:match("([^/]+)$")
if not nombreOriginal or nombreOriginal == "" then
nombreOriginal = "archivo_descargado.bin"
end
local carpetaDescargas = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath()
local rutaDestino = carpetaDescargas .. "/" .. nombreOriginal
local totalBytes = conn.getContentLength()
local input = conn.getInputStream()
local fos = FileOutputStream(rutaDestino)
local buffer = byte[8192]
local descargado = 0
local ultimoPorcentajeHablado = -1
local len = input.read(buffer)
while len > 0 do
fos.write(buffer, 0, len)
descargado = descargado + len
if totalBytes > 0 then
local porcentaje = math.floor(descargado * 100 / totalBytes)
local hito = math.floor(porcentaje / 5) * 5
if hito > ultimoPorcentajeHablado and hito > 0 then
ultimoPorcentajeHablado = hito
if service and service.asyncSpeak then service.asyncSpeak(hito .. " por ciento") end
end
end
len = input.read(buffer)
end
fos.close()
input.close()
return nombreOriginal
end)
return ok, res
end
task(logica_descarga, urlGithub, function(ok, res)
if ok then
speak("archivo descargado exitosamente")
toast("Guardado como: " .. tostring(res))
else
speak("Error al descargar")
toast("Error en descarga")
end
end)
end
local function logicaDescargaTexto(gistId, nombreArchivo, token)
local ok, resultado = pcall(function()
local urlApi = "https://api.github.com/gists/" .. gistId
local uApi = URL(urlApi)
local connApi = uApi.openConnection()
connApi.setRequestProperty("User-Agent", "Mozilla/5.0")
if token and token ~= "" then
connApi.setRequestProperty("Authorization", "token " .. token)
end
connApi.setRequestProperty("Cache-Control", "no-cache")
connApi.connect()
local codeApi = connApi.getResponseCode()
if codeApi ~= 200 then
error("Error al consultar API: " .. tostring(codeApi))
end
local streamApi = connApi.getInputStream()
local readerApi = BufferedReader(InputStreamReader(streamApi))
local sbApi = {}
local lineaApi = readerApi.readLine()
while lineaApi ~= nil do
table.insert(sbApi, lineaApi)
lineaApi = readerApi.readLine()
end
readerApi.close()
local jsonRespuesta = table.concat(sbApi, "\n")
local archEscapado = nombreArchivo:gsub("%.", "%%.")
local patron = '"raw_url"%s*:%s*"([^"]+' .. archEscapado .. ')"'
local rawUrlExacta = jsonRespuesta:match(patron)
if not rawUrlExacta then
error("No se encontró la URL actualizada en la respuesta")
end
local u = URL(rawUrlExacta)
local conn = u.openConnection()
conn.setInstanceFollowRedirects(true)
conn.setRequestProperty("User-Agent", "Mozilla/5.0")
conn.setRequestProperty("Cache-Control", "no-cache")
conn.setConnectTimeout(15000)
conn.setReadTimeout(15000)
conn.connect()
local code = conn.getResponseCode()
if code == 301 or code == 302 or code == 303 or code == 307 or code == 308 then
local redirectUrl = conn.getHeaderField("Location")
if redirectUrl then
u = URL(redirectUrl)
conn = u.openConnection()
conn.setRequestProperty("User-Agent", "Mozilla/5.0")
conn.setConnectTimeout(15000)
conn.setReadTimeout(15000)
conn.connect()
code = conn.getResponseCode()
end
end
if code ~= 200 then
error("Código HTTP " .. tostring(code) .. " al descargar la lista")
end
local carpetaDescargas = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath()
local rutaTemp = carpetaDescargas .. "/lista_capitulos_temp.txt"
local input = conn.getInputStream()
local fos = FileOutputStream(rutaTemp)
local buffer = byte[8192]
local len = input.read(buffer)
while len > 0 do
fos.write(buffer, 0, len)
len = input.read(buffer)
end
fos.close()
input.close()
local f = io.open(rutaTemp, "r")
if not f then
error("Se descargó pero no se pudo abrir el archivo local")
end
local texto = f:read("*a")
f:close()
return texto
end)
return ok, resultado
end
local function parsearFormatoSimple(texto)
local series = {}
local individuales = {}
local destino = nil
for linea in texto:gmatch("[^\r\n]+") do
linea = linea:match("^%s*(.-)%s*$")
if linea ~= "" then
if linea:upper() == "[INDIVIDUALES]" then
destino = individuales
else
local carpeta = linea:match("^%[CARPETA%]%s*(.+)$")
if carpeta then
local nueva = { titulo = carpeta, capitulos = {} }
table.insert(series, nueva)
destino = nueva.capitulos
elseif destino then
local nombre, url = linea:match("^(.-)%s*=%s*(.+)$")
if nombre and url then
table.insert(destino, { nombre = nombre, githubUrl = url })
end
end
end
end
end
return series, individuales
end
local function construirTextoFormato()
local lineas = {}
table.insert(lineas, "[INDIVIDUALES]")
for _, cap in ipairs(INDIVIDUALES) do
table.insert(lineas, cap.nombre .. " = " .. cap.githubUrl)
end
table.insert(lineas, "")
for _, serie in ipairs(SERIES) do
table.insert(lineas, "[CARPETA] " .. serie.titulo)
for _, cap in ipairs(serie.capitulos) do
table.insert(lineas, cap.nombre .. " = " .. cap.githubUrl)
end
table.insert(lineas, "")
end
return table.concat(lineas, "\n")
end
local function guardarEnGithub(nuevoTexto, callback)
if GITHUB_TOKEN == "" then
toast("Error: No hay token de GitHub configurado")
speak("No hay token configurado")
solicitarTokenDialogo(true)
return
end
toast("Guardando cambios en GitHub...")
speak("Guardando cambios en el servidor")
local logica_envio = function(pToken, pGistId, pContenido)
local ok, res = pcall(function()
local urlApi = "https://api.github.com/gists/" .. pGistId
local u = URL(urlApi)
local conn = u.openConnection()
conn.setRequestMethod("PATCH")
conn.setRequestProperty("Authorization", "token " .. pToken)
conn.setRequestProperty("Accept", "application/vnd.github.v3+json")
conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
conn.setDoOutput(true)
local contenidoEscapado = pContenido:gsub('\\', '\\\\'):gsub('"', '\\"'):gsub('\n', '\\n'):gsub('\r', '')
local jsonPayload = '{"files": {"file1.txt": {"content": "' .. contenidoEscapado .. '"}}}'
local out = OutputStreamWriter(conn.getOutputStream(), "UTF-8")
out.write(jsonPayload)
out.flush()
out.close()
local code = conn.getResponseCode()
if code == 200 then
return true
else
local streamErr = conn.getErrorStream()
local cuerpoErr = ""
if streamErr then
local reader = BufferedReader(InputStreamReader(streamErr))
local sb = {}
local linea = reader.readLine()
while linea ~= nil do table.insert(sb, linea); linea = reader.readLine() end
reader.close()
cuerpoErr = table.concat(sb, "\n")
end
error("Código " .. tostring(code) .. ": " .. cuerpoErr)
end
end)
return ok, res
end
task(logica_envio, GITHUB_TOKEN, GIST_ID, nuevoTexto, function(ok, res)
if ok then
toast("¡Cambios guardados con éxito!")
speak("Cambios guardados con éxito")
if callback then callback() end
else
mostrarError("Error al guardar en GitHub", tostring(res))
end
end)
end
local function fusionarSerie(serieRemota)
local existente = nil
for _, s in ipairs(SERIES) do
if s.titulo == serieRemota.titulo then
existente = s
break
end
end
if existente then
for _, capRemoto in ipairs(serieRemota.capitulos) do
local yaExiste = false
for _, capLocal in ipairs(existente.capitulos) do
if capLocal.nombre == capRemoto.nombre then
yaExiste = true
break
end
end
if not yaExiste then
table.insert(existente.capitulos, capRemoto)
end
end
else
table.insert(SERIES, serieRemota)
end
end
local function sincronizarDesdeGitHub(callback)
toast("Actualizando lista de capítulos...")
task(logicaDescargaTexto, GIST_ID, NOMBRE_ARCHIVO_GIST, GITHUB_TOKEN, function(ok, resultado)
if ok and resultado and tostring(resultado) ~= "" then
SERIES = {}
INDIVIDUALES = {}
local seriesRemotas, individualesRemotos = parsearFormatoSimple(tostring(resultado))
for _, serieRemota in ipairs(seriesRemotas) do
fusionarSerie(serieRemota)
end
INDIVIDUALES = individualesRemotos
if #SERIES == 0 and #INDIVIDUALES == 0 then
toast("Todavía no hay carpetas ni archivos creados")
speak("Todavía no hay archivos creados")
else
toast("Lista actualizada")
end
else
local mensajeError = tostring(resultado or "sin conexión")
toast("Error al conectar: " .. mensajeError)
speak("No se pudo conectar a internet")
end
if callback then callback() end
end)
end
local function confirmarEliminar(mensaje, alConfirmar)
local dlg
local layout = {
LinearLayout, orientation = "vertical", padding = "20dp",
{ TextView, text = mensaje, textColor = "#FFFFFF", textSize = "16sp" },
}
dlg = LuaDialog(ctx)
dlg.setTitle("Confirmar eliminación")
dlg.setView(loadlayout(layout))
dlg.setCancelable(true)
dlg.setPositiveButton("Sí", function()
dlg.dismiss()
alConfirmar()
end)
dlg.setNegativeButton("No", function() dlg.dismiss() end)
dlg.show()
end
local function dialogoFormulario(titulo, campos, onGuardar, onCancelar)
local dlg
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", padding = "16dp", background = "#0D0D1A",
{ TextView, text = titulo, textSize = "18sp", textColor = "#FFFFFF", paddingBottom = "8dp" },
}
for i, c in ipairs(campos) do
if c.etiqueta then
table.insert(layout, { TextView, text = c.etiqueta, textColor = "#FFFFFF", textSize = "16sp", layout_marginTop = "8dp" })
end
table.insert(layout, {
EditText, id = "etFormulario_" .. i, hint = c.hint or "", text = c.valor or "",
textColor = "#FFFFFF", hintTextColor = "#666666", background = "#1E1E2E", layout_marginBottom = "8dp"
})
end
table.insert(layout, {
LinearLayout, orientation = "horizontal", layout_width = "match_parent", layout_marginTop = "12dp",
{ Button, text = "Cancelar", textColor = "#FFFFFF", background = "#6B1A1A", layout_width = "0dp", layout_weight = "1", layout_marginRight = "8dp",
onClick = function()
vibrar()
dlg.dismiss()
if onCancelar then onCancelar() end
end },
{ Button, text = "Guardar", textColor = "#FFFFFF", background = "#107C41", layout_width = "0dp", layout_weight = "1",
onClick = function()
vibrar()
local valores = {}
for i = 1, #campos do
valores[i] = recortar(_ENV["etFormulario_" .. i].getText())
if valores[i] == "" then
toast("Completa todos los campos")
speak("Completa todos los campos")
return
end
end
dlg.dismiss()
onGuardar(valores)
end },
})
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
speak(titulo)
end
local function dialogoOpciones(opciones)
vibrar()
local dlg
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", padding = "16dp", background = "#0D0D1A",
{ TextView, text = "Opciones", textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingBottom = "16dp" },
}
for _, op in ipairs(opciones) do
table.insert(layout, {
Button, text = op.texto, textSize = "16sp", textColor = "#FFFFFF", background = "#1E1E2E",
layout_width = "match_parent", layout_marginBottom = "10dp",
onClick = function()
vibrar()
dlg.dismiss()
op.fn()
end
})
end
table.insert(layout, {
Button, text = "Cancelar", textSize = "16sp", textColor = "#FFFFFF", background = "#6B1A1A", layout_width = "match_parent",
onClick = function()
vibrar()
dlg.dismiss()
end
})
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(true)
dlg.show()
speak("Opciones")
end
local function pantallaLista(cfg)
local dlg
local contenido = {
LinearLayout, orientation = "vertical", layout_width = "match_parent",
paddingLeft = "16dp", paddingRight = "16dp", paddingTop = "8dp", paddingBottom = "16dp",
}
if #cfg.items == 0 then
table.insert(contenido, { TextView, text = cfg.vacio or "No hay elementos.", textColor = "#AAAAAA", textSize = "16sp", padding = "12dp" })
else
for i, it in ipairs(cfg.items) do
table.insert(contenido, {
TextView, id = "tvLista_" .. i, text = it.texto, textSize = "18sp", textColor = "#FFFFFF",
background = "#1E1E2E", padding = "14dp", layout_width = "match_parent", layout_marginTop = "8dp",
onClick = function()
vibrar()
it.onClick()
end
})
end
end
local cabecera = {
LinearLayout, orientation = "horizontal", layout_width = "match_parent", background = "#1A1A2E",
paddingTop = "16dp", paddingBottom = "16dp", paddingLeft = "16dp", paddingRight = "8dp", gravity = "center_vertical",
{ TextView, text = cfg.titulo, textSize = "20sp", textColor = "#FFFFFF", layout_width = "0dp", layout_weight = "1" },
}
if cfg.botonHeader then
table.insert(cabecera, {
Button, text = cfg.botonHeader, textSize = "12sp", textColor = "#FFFFFF", background = "#107C41",
onClick = function()
vibrar()
cfg.onHeader()
end
})
end
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#0D0D1A",
cabecera,
{ ScrollView, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1", contenido },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "right", padding = "12dp", background = "#1A1A2E",
{ Button, text = "Volver", textColor = "#FFFFFF", background = "#3D3D6B",
onClick = function()
vibrar()
cfg.onVolver()
end },
},
}
if cfg.subtitulo then
table.insert(layout, 3, {
TextView, text = cfg.subtitulo, textSize = "14sp", textColor = "#AAAAAA",
paddingLeft = "16dp", paddingRight = "16dp", paddingTop = "8dp", layout_width = "match_parent"
})
end
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
speak(cfg.titulo)
for i, it in ipairs(cfg.items) do
if it.onLongClick then
local tv = _ENV["tvLista_" .. i]
if tv ~= nil then
setLongClick(tv, function()
it.onLongClick()
end)
end
end
end
return dlg
end
local mostrarDetalleCapitulo, pantallaCapitulosAdmin
mostrarDetalleCapitulo = function(idx, getLista, alTerminar)
local cap = getLista()[idx]
if not cap then
alTerminar()
return
end
local dlg
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", padding = "16dp", background = "#0D0D1A",
{ TextView, text = cap.nombre, textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingBottom = "20dp" },
{ Button, text = "Editar", textSize = "16sp", textColor = "#FFFFFF", background = "#1E1E2E", layout_width = "match_parent", layout_marginBottom = "12dp",
onClick = function()
vibrar()
dialogoFormulario("Ingrese el nombre del capítulo", {
{ hint = "Nombre del capítulo", valor = cap.nombre },
{ etiqueta = "Ingrese el enlace", hint = "Enlace del capítulo", valor = cap.githubUrl },
}, function(v)
cap.nombre = v[1]
cap.githubUrl = v[2]
guardarEnGithub(construirTextoFormato(), function()
dlg.dismiss()
alTerminar()
end)
end)
end },
{ Button, text = "Eliminar", textSize = "16sp", textColor = "#FFFFFF", background = "#6B1A1A", layout_width = "match_parent",
onClick = function()
vibrar()
confirmarEliminar("¿Eliminar el capítulo \"" .. cap.nombre .. "\"?", function()
table.remove(getLista(), idx)
guardarEnGithub(construirTextoFormato(), function()
dlg.dismiss()
alTerminar()
end)
end)
end },
{ LinearLayout, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1" },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "right",
{ Button, text = "Volver", textColor = "#FFFFFF", background = "#3D3D6B",
onClick = function()
vibrar()
dlg.dismiss()
alTerminar()
end },
}
}
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
speak(cap.nombre)
end
pantallaCapitulosAdmin = function(getTitulo, getLista, alVolver)
local dlg
local items = {}
for i, cap in ipairs(getLista()) do
local idx = i
table.insert(items, {
texto = cap.nombre,
onClick = function()
dlg.dismiss()
mostrarDetalleCapitulo(idx, getLista, function()
pantallaCapitulosAdmin(getTitulo, getLista, alVolver)
end)
end
})
end
dlg = pantallaLista({
titulo = getTitulo(),
botonHeader = "Crear archivo",
onHeader = function()
dialogoFormulario("Ingrese el nombre del capítulo", {
{ hint = "Nombre del capítulo" },
{ etiqueta = "Ingrese el enlace", hint = "Enlace del capítulo" },
}, function(v)
table.insert(getLista(), { nombre = v[1], githubUrl = v[2] })
guardarEnGithub(construirTextoFormato(), function()
dlg.dismiss()
pantallaCapitulosAdmin(getTitulo, getLista, alVolver)
end)
end)
end,
items = items,
vacio = "Todavía no hay capítulos creados.",
onVolver = function()
dlg.dismiss()
alVolver()
end
})
end
local function mostrarAdminCarpetas(alVolver)
local dlg
local items = {}
for i, serie in ipairs(SERIES) do
local idx = i
local titulo = serie.titulo
table.insert(items, {
texto = titulo,
onClick = function()
dlg.dismiss()
pantallaCapitulosAdmin(
function() return SERIES[idx] and SERIES[idx].titulo or "" end,
function() return SERIES[idx].capitulos end,
function() mostrarAdminCarpetas(alVolver) end
)
end,
onLongClick = function()
dialogoOpciones({
{ texto = "Eliminar", fn = function()
confirmarEliminar("¿Eliminar toda la carpeta \"" .. titulo .. "\" y todos sus capítulos?", function()
table.remove(SERIES, idx)
guardarEnGithub(construirTextoFormato(), function()
dlg.dismiss()
mostrarAdminCarpetas(alVolver)
end)
end)
end },
{ texto = "Renombrar", fn = function()
dialogoFormulario("Ingrese el nuevo nombre de la carpeta", {
{ hint = "Nombre de la carpeta", valor = titulo },
}, function(v)
for j, s in ipairs(SERIES) do
if j ~= idx and s.titulo == v[1] then
toast("Ya existe una carpeta con ese nombre")
return
end
end
SERIES[idx].titulo = v[1]
guardarEnGithub(construirTextoFormato(), function()
dlg.dismiss()
mostrarAdminCarpetas(alVolver)
end)
end)
end },
})
end
})
end
dlg = pantallaLista({
titulo = "Administrador de carpetas",
botonHeader = "Crear carpeta",
onHeader = function()
dialogoFormulario("Ingrese el nombre de la carpeta", {
{ hint = "Nombre de la carpeta" },
}, function(v)
for _, s in ipairs(SERIES) do
if s.titulo == v[1] then
toast("Ya existe una carpeta con ese nombre")
return
end
end
table.insert(SERIES, { titulo = v[1], capitulos = {} })
guardarEnGithub(construirTextoFormato(), function()
dlg.dismiss()
mostrarAdminCarpetas(alVolver)
end)
end)
end,
items = items,
vacio = "Todavía no hay carpetas creadas.",
onVolver = function()
dlg.dismiss()
alVolver()
end
})
end
local function mostrarAdminIndividuales(alVolver)
pantallaCapitulosAdmin(
function() return "Administrador de archivos individuales" end,
function() return INDIVIDUALES end,
alVolver
)
end
local function mostrarFiltro(alVolver)
local dlg
local function etiqueta(texto, valor)
if FILTRO == valor then return texto .. " ✓" end
return texto
end
local function opcion(texto, valor)
return {
Button, text = etiqueta(texto, valor), textSize = "16sp", textColor = "#FFFFFF",
background = (FILTRO == valor) and "#0F52BA" or "#1E1E2E",
layout_width = "match_parent", layout_marginBottom = "12dp",
onClick = function()
vibrar()
FILTRO = valor
guardarFiltroLocal(valor)
toast("Filtro aplicado: " .. texto)
speak("Filtro aplicado: " .. texto)
dlg.dismiss()
alVolver()
end
}
end
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", padding = "16dp", background = "#0D0D1A",
{ TextView, text = "Filtro de archivo", textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingBottom = "8dp" },
{ TextView, text = "Elige qué contenido quieres ver en la interfaz principal.", textSize = "14sp", textColor = "#AAAAAA", paddingBottom = "16dp" },
opcion("Todo el contenido", "todos"),
opcion("Solo carpetas", "carpetas"),
opcion("Solo archivos individuales", "individuales"),
{ LinearLayout, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1" },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "right",
{ Button, text = "Cerrar", textColor = "#FFFFFF", background = "#3D3D6B",
onClick = function()
vibrar()
dlg.dismiss()
alVolver()
end },
}
}
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
speak("Filtro de archivo")
end
local function tareaApi(metodo, urlStr, token, cuerpo)
return pcall(function()
local URL = luajava.bindClass("java.net.URL")
local BufferedReader = luajava.bindClass("java.io.BufferedReader")
local InputStreamReader = luajava.bindClass("java.io.InputStreamReader")
local OutputStreamWriter = luajava.bindClass("java.io.OutputStreamWriter")
local conn = URL(urlStr).openConnection()
conn.setRequestMethod(metodo)
conn.setRequestProperty("User-Agent", "Mozilla/5.0")
conn.setRequestProperty("Accept", "application/vnd.github+json")
conn.setRequestProperty("Authorization", "token " .. token)
conn.setConnectTimeout(20000)
conn.setReadTimeout(60000)
if cuerpo and cuerpo ~= "" then
conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
conn.setDoOutput(true)
local out = OutputStreamWriter(conn.getOutputStream(), "UTF-8")
out.write(cuerpo)
out.flush()
out.close()
end
local code = conn.getResponseCode()
local stream
if code >= 400 then
stream = conn.getErrorStream()
else
stream = conn.getInputStream()
end
local texto = ""
if stream then
local reader = BufferedReader(InputStreamReader(stream, "UTF-8"))
local sb = {}
local linea = reader.readLine()
while linea ~= nil do
table.insert(sb, linea)
linea = reader.readLine()
end
reader.close()
texto = table.concat(sb, "\n")
end
return code, texto
end)
end
local function tareaLeerBase64(rutaLocal, texto)
return pcall(function()
local ByteArrayOutputStream = luajava.bindClass("java.io.ByteArrayOutputStream")
local FileInputStream = luajava.bindClass("java.io.FileInputStream")
local OutputStreamWriter = luajava.bindClass("java.io.OutputStreamWriter")
local Base64 = luajava.bindClass("android.util.Base64")
local baos = ByteArrayOutputStream()
if rutaLocal ~= "" then
local fis = FileInputStream(rutaLocal)
local buffer = byte[65536]
local len = fis.read(buffer)
while len > 0 do
baos.write(buffer, 0, len)
len = fis.read(buffer)
end
fis.close()
else
local w = OutputStreamWriter(baos, "UTF-8")
w.write(texto)
w.flush()
w.close()
end
return tostring(Base64.encodeToString(baos.toByteArray(), 2))
end)
end
local function tareaSubirAsset(uploadBase, token, rutaLocal, nombre)
return pcall(function()
local URL = luajava.bindClass("java.net.URL")
local File = luajava.bindClass("java.io.File")
local FileInputStream = luajava.bindClass("java.io.FileInputStream")
local URLEncoder = luajava.bindClass("java.net.URLEncoder")
local URLConnection = luajava.bindClass("java.net.URLConnection")
local BufferedReader = luajava.bindClass("java.io.BufferedReader")
local InputStreamReader = luajava.bindClass("java.io.InputStreamReader")
local f = File(rutaLocal)
local largo = f.length()
local tipo = URLConnection.guessContentTypeFromName(nombre)
if tipo == nil then tipo = "application/octet-stream" end
local nombreEnc = tostring(URLEncoder.encode(nombre, "UTF-8")):gsub("%+", "%%20")
local conn = URL(uploadBase .. "?name=" .. nombreEnc).openConnection()
conn.setRequestMethod("POST")
conn.setRequestProperty("User-Agent", "Mozilla/5.0")
conn.setRequestProperty("Accept", "application/vnd.github+json")
conn.setRequestProperty("Authorization", "token " .. token)
conn.setRequestProperty("Content-Type", tostring(tipo))
conn.setConnectTimeout(20000)
conn.setReadTimeout(300000)
conn.setDoOutput(true)
local okFijo = pcall(function() conn.setFixedLengthStreamingMode(largo) end)
if not okFijo then conn.setChunkedStreamingMode(0) end
local os = conn.getOutputStream()
local fis = FileInputStream(f)
local buffer = byte[65536]
local len = fis.read(buffer)
while len > 0 do
os.write(buffer, 0, len)
len = fis.read(buffer)
end
fis.close()
os.flush()
os.close()
local code = conn.getResponseCode()
local stream
if code >= 400 then
stream = conn.getErrorStream()
else
stream = conn.getInputStream()
end
local texto = ""
if stream then
local reader = BufferedReader(InputStreamReader(stream, "UTF-8"))
local sb = {}
local linea = reader.readLine()
while linea ~= nil do
table.insert(sb, linea)
linea = reader.readLine()
end
reader.close()
texto = table.concat(sb, "\n")
end
return code, texto
end)
end
local function jsonEsc(s)
s = tostring(s)
s = s:gsub("\\", "\\\\")
s = s:gsub('"', '\\"')
s = s:gsub("\n", "\\n")
s = s:gsub("\r", "\\r")
s = s:gsub("\t", "\\t")
return s
end
local function codificarComponente(s)
local URLEncoder = luajava.bindClass("java.net.URLEncoder")
local r = tostring(URLEncoder.encode(s, "UTF-8")):gsub("%+", "%%20")
return r
end
local function codificarRuta(ruta)
local partes = {}
for seg in ruta:gmatch("[^/]+") do
table.insert(partes, codificarComponente(seg))
end
return table.concat(partes, "/")
end
local function formatearTamano(bytes)
if not bytes or bytes < 1024 then return tostring(bytes or 0) .. " B" end
if bytes < 1024 * 1024 then return string.format("%.1f KB", bytes / 1024) end
if bytes < 1024 * 1024 * 1024 then return string.format("%.1f MB", bytes / (1024 * 1024)) end
return string.format("%.2f GB", bytes / (1024 * 1024 * 1024))
end
local function explicarErrorGithub(code, body)
if type(code) ~= "number" then
return "Error de conexión: " .. tostring(code)
end
body = tostring(body or "")
local mensajes = {}
for m in body:gmatch('"message"%s*:%s*"([^"]*)"') do
table.insert(mensajes, m)
end
local detalle = table.concat(mensajes, "\n")
local pista = ""
if code == 401 then
pista = "El token no es válido o ya venció."
elseif code == 403 then
pista = "El token no tiene permisos suficientes o se alcanzó un límite de GitHub."
elseif code == 404 then
pista = "No se encontró el repositorio, o el token no tiene acceso a él."
elseif code == 422 then
if body:find("target_commitish", 1, true) then
pista = "La rama indicada no existe o el repositorio está vacío. Crea primero un archivo en el repositorio (opción Crear archivo) o deja la rama en blanco."
elseif body:find("already_exists", 1, true) then
pista = "Ya existe un elemento con ese nombre (repositorio, etiqueta o archivo)."
end
end
local texto = "Código " .. tostring(code)
if detalle ~= "" then texto = texto .. "\n" .. detalle end
if pista ~= "" then texto = texto .. "\n\n" .. pista end
return texto
end
local function mostrarMensaje(titulo, mensaje, alCerrar)
local dlg
local layout = {
LinearLayout, orientation = "vertical", padding = "20dp",
{ TextView, text = mensaje, textColor = "#FFFFFF", textSize = "16sp" },
}
dlg = LuaDialog(ctx)
dlg.setTitle(titulo)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.setPositiveButton("Aceptar", function()
dlg.dismiss()
if alCerrar then alCerrar() end
end)
dlg.show()
speak(titulo)
end
local function campo(etiqueta, id, hint)
return {
LinearLayout, orientation = "vertical", layout_width = "match_parent",
{ TextView, text = etiqueta, textColor = "#FFFFFF", textSize = "15sp", layout_marginTop = "12dp" },
{ EditText, id = id, hint = hint or "", textColor = "#FFFFFF", hintTextColor = "#666666", background = "#1E1E2E" },
}
end
local function casilla(id, texto)
return { CheckBox, id = id, text = texto, textColor = "#FFFFFF", textSize = "16sp", layout_marginTop = "6dp" }
end
local function botonForm(texto, fn)
return {
Button, text = texto, textSize = "15sp", textColor = "#FFFFFF", background = "#1E1E2E",
layout_width = "match_parent", layout_marginTop = "12dp",
onClick = function()
vibrar()
fn()
end
}
end
local function mostrarPantallaForm(titulo, hijos, textoAccion, onAccion, onCancelar)
local dlg
local contenido = { LinearLayout, orientation = "vertical", layout_width = "match_parent", padding = "16dp" }
for _, h in ipairs(hijos) do table.insert(contenido, h) end
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#0D0D1A",
{ TextView, text = titulo, textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingTop = "16dp", paddingBottom = "16dp", layout_width = "match_parent", background = "#1A1A2E" },
{ ScrollView, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1", contenido },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", padding = "12dp", background = "#1A1A2E",
{ Button, text = "Cancelar", textColor = "#FFFFFF", background = "#6B1A1A", layout_width = "0dp", layout_weight = "1", layout_marginRight = "8dp",
onClick = function()
vibrar()
onCancelar(dlg)
end },
{ Button, text = textoAccion, textColor = "#FFFFFF", background = "#107C41", layout_width = "0dp", layout_weight = "1",
onClick = function()
vibrar()
onAccion(dlg)
end },
},
}
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
speak(titulo)
return dlg
end
local function obtenerRepositorios(callback, mensaje)
if GITHUB_TOKEN == "" then
toast("Primero configura el token")
speak("Primero configura el token")
solicitarTokenDialogo(true)
callback(nil)
return
end
mensaje = mensaje or "Cargando repositorios"
toast(mensaje)
speak(mensaje)
local nombres = {}
local vistos = {}
local function cargarPagina(pagina)
local url = "https://api.github.com/user/repos?per_page=100&sort=updated&page=" .. pagina
task(tareaApi, "GET", url, GITHUB_TOKEN, "", function(ok, code, body)
if not ok or code ~= 200 then
mostrarError("No se pudieron cargar los repositorios", explicarErrorGithub(code, body))
callback(nil)
return
end
local cantidad = 0
for n in tostring(body):gmatch('"full_name"%s*:%s*"([^"]+)"') do
cantidad = cantidad + 1
if not vistos[n] then
vistos[n] = true
table.insert(nombres, n)
end
end
if cantidad >= 100 and pagina < 5 then
cargarPagina(pagina + 1)
else
callback(nombres)
end
end)
end
cargarPagina(1)
end
local function elegirRepositorio(alElegir, alCancelar, titulo)
obtenerRepositorios(function(nombres)
if not nombres then
if alCancelar then alCancelar() end
return
end
local dlg
local items = {}
for _, n in ipairs(nombres) do
table.insert(items, {
texto = n,
onClick = function()
dlg.dismiss()
alElegir(n)
end
})
end
dlg = pantallaLista({
titulo = titulo or "Elige un repositorio",
items = items,
vacio = "No se encontraron repositorios.",
onVolver = function()
dlg.dismiss()
if alCancelar then alCancelar() end
end
})
end)
end
local function arrayAFiles(arr)
local t = {}
local ok, n = pcall(function() return #arr end)
if ok and type(n) == "number" then
for i = 0, n - 1 do t[#t + 1] = arr[i] end
return t
end
local ok2, tt = pcall(function() return luajava.astable(arr) end)
if ok2 and type(tt) == "table" then return tt end
local i = 0
while true do
local ok3, v = pcall(function() return arr[i] end)
if not ok3 or v == nil then break end
t[#t + 1] = v
i = i + 1
end
return t
end
local function recolectarArchivos(ruta, res, limite)
local lista = File(ruta).listFiles()
if lista == nil then return end
for _, f in ipairs(arrayAFiles(lista)) do
if #res >= limite then return end
if f.isDirectory() then
recolectarArchivos(tostring(f.getAbsolutePath()), res, limite)
else
table.insert(res, tostring(f.getAbsolutePath()))
end
end
end
local function mostrarExplorador(unico, seleccionInicial, alAdjuntar)
local raiz = tostring(Environment.getExternalStorageDirectory().getAbsolutePath())
local rutaActual = raiz
local orden = {}
local sel = {}
local esCarpeta = {}
local dlg
local etBuscar, tvTitulo, tvSub, llLista, barraVolver, barraAdjuntar, btnAdjuntar
local listar
local textoSub = "A continuación, seleccione el archivo a adjuntar"
if not unico then
textoSub = textoSub .. ". Mantenga pulsada una carpeta para añadirla completa."
end
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#0D0D1A",
{ TextView, id = "tvTituloExp", text = "Administrador de archivos", textSize = "22sp", textColor = "#FFFFFF", gravity = "center",
paddingTop = "16dp", paddingBottom = "16dp", layout_width = "match_parent", background = "#1A1A2E" },
{ EditText, id = "etBuscarExp", hint = "Buscar", textColor = "#FFFFFF", hintTextColor = "#666666", background = "#1E1E2E",
layout_width = "match_parent", layout_marginLeft = "8dp", layout_marginRight = "8dp", layout_marginTop = "8dp", layout_marginBottom = "8dp", singleLine = true },
{ TextView, id = "tvSubExp", text = textoSub, textSize = "14sp", textColor = "#AAAAAA",
paddingLeft = "12dp", paddingRight = "12dp", paddingBottom = "4dp", layout_width = "match_parent" },
{
ScrollView, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1",
{ LinearLayout, id = "llListaExp", orientation = "vertical", layout_width = "match_parent", padding = "8dp" },
},
{
LinearLayout, orientation = "vertical", layout_width = "match_parent", background = "#1A1A2E",
{
LinearLayout, id = "barraVolverExp", orientation = "horizontal", layout_width = "match_parent", gravity = "right", padding = "12dp",
{ Button, text = "Volver", textColor = "#FFFFFF", background = "#3D3D6B",
onClick = function()
vibrar()
if rutaActual == raiz then
dlg.dismiss()
else
local padre = File(rutaActual).getParent()
padre = padre and tostring(padre) or raiz
if #padre < #raiz then padre = raiz end
rutaActual = padre
etBuscar.setText("")
listar()
speak(tostring(tvTitulo.getText()))
end
end },
},
{
LinearLayout, id = "barraAdjuntarExp", orientation = "horizontal", layout_width = "match_parent", padding = "12dp",
{ Button, text = "Cancelar", textColor = "#FFFFFF", background = "#6B1A1A", layout_width = "0dp", layout_weight = "1", layout_marginRight = "8dp",
onClick = function()
vibrar()
sel = {}
orden = {}
esCarpeta = {}
listar()
speak("Selección cancelada")
end },
{ Button, id = "btnAdjuntarExp", text = "Adjuntar", textColor = "#FFFFFF", background = "#107C41", layout_width = "0dp", layout_weight = "1",
onClick = function()
vibrar()
if #orden == 0 then
toast("Selecciona al menos un archivo")
return
end
local copia = {}
local vistos = {}
for _, r in ipairs(orden) do
if esCarpeta[r] then
local dentro = {}
recolectarArchivos(r, dentro, 1000)
for _, x in ipairs(dentro) do
if not vistos[x] then
vistos[x] = true
table.insert(copia, x)
end
end
elseif not vistos[r] then
vistos[r] = true
table.insert(copia, r)
end
end
if #copia == 0 then
toast("Las carpetas seleccionadas no tienen archivos")
speak("Las carpetas seleccionadas no tienen archivos")
return
end
if #copia >= 1000 then
toast("Se añadieron los primeros 1000 archivos, que es el límite de un lanzamiento")
end
dlg.dismiss()
alAdjuntar(copia)
end },
},
},
}
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
etBuscar = etBuscarExp
tvTitulo = tvTituloExp
tvSub = tvSubExp
llLista = llListaExp
barraVolver = barraVolverExp
barraAdjuntar = barraAdjuntarExp
btnAdjuntar = btnAdjuntarExp
local function agregarItem(texto, color, fn, fnLargo)
local fila = loadlayout({
LinearLayout, orientation = "vertical", layout_width = "match_parent", paddingBottom = "6dp",
{
TextView, text = texto, textSize = "17sp", textColor = color, background = "#1E1E2E",
padding = "12dp", layout_width = "match_parent",
onClick = function()
vibrar()
if fn then fn() end
end
},
})
if fnLargo then
setLongClick(fila.getChildAt(0), function()
vibrar()
fnLargo()
end)
end
llLista.addView(fila)
end
local function alternarSeleccion(ruta, nombre, esDir)
if sel[ruta] then
sel[ruta] = nil
esCarpeta[ruta] = nil
for i, r in ipairs(orden) do
if r == ruta then table.remove(orden, i) break end
end
speak("Deseleccionado: " .. nombre)
else
if unico then
sel = {}
orden = {}
esCarpeta = {}
end
sel[ruta] = true
if esDir then esCarpeta[ruta] = true end
table.insert(orden, ruta)
if esDir then
speak("Carpeta seleccionada: " .. nombre)
else
speak("Seleccionado: " .. nombre)
end
end
listar()
end
listar = function()
llLista.removeAllViews()
if rutaActual == raiz then
tvTitulo.setText("Administrador de archivos")
tvSub.setVisibility(View.GONE)
else
tvTitulo.setText(tostring(File(rutaActual).getName()))
tvSub.setVisibility(View.VISIBLE)
end
if #orden > 0 then
barraVolver.setVisibility(View.GONE)
barraAdjuntar.setVisibility(View.VISIBLE)
local hayCarpeta = false
for _, r in ipairs(orden) do
if esCarpeta[r] then hayCarpeta = true end
end
if hayCarpeta then btnAdjuntar.setText("Añadir") else btnAdjuntar.setText("Adjuntar") end
else
barraVolver.setVisibility(View.VISIBLE)
barraAdjuntar.setVisibility(View.GONE)
end
local filtro = tostring(etBuscar.getText()):lower()
local lista = File(rutaActual).listFiles()
if lista == nil then
agregarItem("No se puede acceder a esta carpeta. Revisa el permiso de almacenamiento.", "#AAAAAA", nil)
return
end
local carpetas, archivos = {}, {}
for _, f in ipairs(arrayAFiles(lista)) do
local nombre = tostring(f.getName())
if filtro == "" or nombre:lower():find(filtro, 1, true) then
local entrada = { nombre = nombre, ruta = tostring(f.getAbsolutePath()), tam = f.length() }
if f.isDirectory() then
table.insert(carpetas, entrada)
else
table.insert(archivos, entrada)
end
end
end
local function porNombre(a, b) return a.nombre:lower() < b.nombre:lower() end
table.sort(carpetas, porNombre)
table.sort(archivos, porNombre)
if #carpetas == 0 and #archivos == 0 then
agregarItem("No hay resultados.", "#AAAAAA", nil)
return
end
for _, c in ipairs(carpetas) do
local ruta = c.ruta
local nombre = c.nombre
local irA = function()
if #orden > 0 then
if unico then
toast("Cancela la selección para cambiar de carpeta")
else
alternarSeleccion(ruta, nombre, true)
end
return
end
rutaActual = ruta
etBuscar.setText("")
listar()
speak(nombre)
end
local largo = nil
if not unico then
largo = function() alternarSeleccion(ruta, nombre, true) end
end
if sel[ruta] then
agregarItem("Carpeta seleccionada: " .. nombre, "#81C784", irA, largo)
else
agregarItem("Carpeta: " .. nombre, "#FFFFFF", irA, largo)
end
end
for _, a in ipairs(archivos) do
local ruta = a.ruta
local nombre = a.nombre
if sel[ruta] then
agregarItem("Seleccionado: " .. nombre .. " (" .. formatearTamano(a.tam) .. ")", "#81C784", function() alternarSeleccion(ruta, nombre) end)
else
agregarItem("Archivo: " .. nombre .. " (" .. formatearTamano(a.tam) .. ")", "#FFFFFF", function() alternarSeleccion(ruta, nombre) end)
end
end
end
etBuscar.addTextChangedListener(luajava.createProxy("android.text.TextWatcher", {
beforeTextChanged = function(s, a, b, c) end,
onTextChanged = function(s, a, b, c) listar() end,
afterTextChanged = function(s) end
}))
listar()
speak("Administrador de archivos")
end
local function mostrarCrearRepositorio(alVolver)
local dlg
local ocupado = false
local privado = false
local etNombre, etDesc, btnVisibilidad
local function textoVisibilidad()
if privado then
return "Visibilidad: Privado (toca para cambiar)"
else
return "Visibilidad: Público (toca para cambiar)"
end
end
local hijos = {
campo("Nombre del repositorio", "etRepoNombre", "mi-repositorio"),
campo("Descripción", "etRepoDescripcion", "Descripción corta"),
{
Button, id = "btnRepoVisibilidad", text = textoVisibilidad(), textSize = "15sp", textColor = "#FFFFFF", background = "#1E1E2E",
layout_width = "match_parent", layout_marginTop = "16dp",
onClick = function()
vibrar()
privado = not privado
btnVisibilidad.setText(textoVisibilidad())
if privado then speak("Privado") else speak("Público") end
end
},
}
local function crear()
if ocupado then return end
if GITHUB_TOKEN == "" then
toast("Primero configura el token")
speak("Primero configura el token")
solicitarTokenDialogo(true)
return
end
local nombre = recortar(etNombre.getText())
if nombre == "" then
toast("Ingresa el nombre del repositorio")
speak("Ingresa el nombre del repositorio")
return
end
if not nombre:match("^[%w%._%-]+$") then
toast("El nombre solo puede tener letras, números, punto, guion y guion bajo")
speak("El nombre solo puede tener letras, números, punto, guion y guion bajo")
return
end
local desc = recortar(etDesc.getText())
local partes = { '"name":"' .. jsonEsc(nombre) .. '"' }
if desc ~= "" then table.insert(partes, '"description":"' .. jsonEsc(desc) .. '"') end
table.insert(partes, '"private":' .. tostring(privado))
table.insert(partes, '"auto_init":true')
local payload = "{" .. table.concat(partes, ",") .. "}"
ocupado = true
toast("Creando repositorio...")
speak("Creando repositorio")
task(tareaApi, "POST", "https://api.github.com/user/repos", GITHUB_TOKEN, payload, function(ok, code, body)
ocupado = false
if ok and code == 201 then
local completo = tostring(body):match('"full_name"%s*:%s*"([^"]+)"') or nombre
mostrarMensaje("Repositorio creado", "https://github.com/" .. completo, function()
dlg.dismiss()
alVolver()
end)
else
mostrarError("No se pudo crear el repositorio", explicarErrorGithub(code, body))
end
end)
end
dlg = mostrarPantallaForm("Crear repositorio", hijos, "Crear",
function() crear() end,
function(d) d.dismiss() alVolver() end)
etNombre = etRepoNombre
etDesc = etRepoDescripcion
btnVisibilidad = btnRepoVisibilidad
end
local function mostrarCrearLanzamiento(alVolver, repoInicial)
local dlg
local ocupado = false
local repoSel = repoInicial or ""
local archivos = {}
local tvRepo, tvAdj, etEtiqueta, etNombre, etNotas
local cbAuto
local function actualizarAdjuntos()
tvAdj.setText("Archivos adjuntos: " .. #archivos)
end
local hijos = {
{ TextView, id = "tvLanzRepo", text = "Repositorio: ninguno", textColor = "#FFFFFF", textSize = "16sp" },
botonForm("Elegir repositorio", function()
elegirRepositorio(function(nombre)
repoSel = nombre
tvRepo.setText("Repositorio: " .. nombre)
speak("Repositorio " .. nombre)
end)
end),
campo("Nombre de la etiqueta", "etLanzEtiqueta", "v1.0.0"),
campo("Nombre del lanzamiento", "etLanzNombre", "Nombre del lanzamiento"),
campo("Notas del lanzamiento", "etLanzNotas", "Describe los cambios"),
casilla("cbLanzAuto", "Generar notas automáticamente"),
{ TextView, id = "tvLanzAdj", text = "Archivos adjuntos: 0", textColor = "#81C784", textSize = "15sp", layout_marginTop = "16dp" },
botonForm("Adjuntar", function()
mostrarExplorador(false, nil, function(lista)
for _, r in ipairs(lista) do
local ya = false
for _, x in ipairs(archivos) do
if x == r then ya = true end
end
if not ya then table.insert(archivos, r) end
end
actualizarAdjuntos()
speak(#archivos .. " archivos adjuntos")
end)
end),
}
local subirSiguiente
local function finalizar(htmlUrl, fallos, enlaces)
ocupado = false
if #fallos == 0 then
local texto = "Lanzamiento creado."
if #enlaces > 0 then
texto = "Enlaces de descarga:\n\n" .. table.concat(enlaces, "\n\n")
end
mostrarMensaje("Lanzamiento creado", texto, function()
dlg.dismiss()
alVolver()
end)
else
mostrarError("Lanzamiento creado, pero fallaron algunos archivos",
htmlUrl .. "\n\n" .. table.concat(fallos, "\n\n"))
end
end
subirSiguiente = function(i, uploadBase, htmlUrl, fallos, enlaces)
if i > #archivos then
finalizar(htmlUrl, fallos, enlaces)
return
end
local ruta = archivos[i]
local nombre = ruta:match("([^/]+)$") or ruta
toast("Subiendo " .. i .. " de " .. #archivos .. ": " .. nombre)
speak("Subiendo archivo " .. i .. " de " .. #archivos)
task(tareaSubirAsset, uploadBase, GITHUB_TOKEN, ruta, nombre, function(ok, code, body)
if ok and code == 201 then
local enlaceDescarga = tostring(body):match('"browser_download_url"%s*:%s*"([^"]+)"')
if enlaceDescarga then table.insert(enlaces, enlaceDescarga) end
else
table.insert(fallos, nombre .. ": " .. explicarErrorGithub(code, body))
end
subirSiguiente(i + 1, uploadBase, htmlUrl, fallos, enlaces)
end)
end
local function crear()
if ocupado then return end
if GITHUB_TOKEN == "" then
toast("Primero configura el token")
speak("Primero configura el token")
solicitarTokenDialogo(true)
return
end
if repoSel == "" then
toast("Elige un repositorio")
speak("Elige un repositorio")
return
end
local etiqueta = recortar(etEtiqueta.getText())
if etiqueta == "" then
toast("Ingresa la etiqueta del lanzamiento")
speak("Ingresa la etiqueta del lanzamiento")
return
end
local nombre = recortar(etNombre.getText())
local notas = tostring(etNotas.getText())
local partes = { '"tag_name":"' .. jsonEsc(etiqueta) .. '"' }
if nombre ~= "" then table.insert(partes, '"name":"' .. jsonEsc(nombre) .. '"') end
if recortar(notas) ~= "" then table.insert(partes, '"body":"' .. jsonEsc(notas) .. '"') end
table.insert(partes, '"draft":false')
table.insert(partes, '"prerelease":false')
table.insert(partes, '"generate_release_notes":' .. tostring(cbAuto.isChecked()))
local payload = "{" .. table.concat(partes, ",") .. "}"
ocupado = true
toast("Creando lanzamiento...")
speak("Creando lanzamiento")
local url = "https://api.github.com/repos/" .. repoSel .. "/releases"
task(tareaApi, "POST", url, GITHUB_TOKEN, payload, function(ok, code, body)
if ok and code == 201 then
local htmlUrl = tostring(body):match('"html_url"%s*:%s*"([^"]+)"') or ""
local uploadBase = tostring(body):match('"upload_url"%s*:%s*"([^"{]+)')
if #archivos > 0 and uploadBase then
subirSiguiente(1, uploadBase, htmlUrl, {}, {})
else
finalizar(htmlUrl, {}, {})
end
else
ocupado = false
mostrarError("No se pudo crear el lanzamiento", explicarErrorGithub(code, body))
end
end)
end
dlg = mostrarPantallaForm("Crear lanzamiento", hijos, "Crear",
function() crear() end,
function(d) d.dismiss() alVolver() end)
tvRepo = tvLanzRepo
tvAdj = tvLanzAdj
etEtiqueta = etLanzEtiqueta
etNombre = etLanzNombre
etNotas = etLanzNotas
cbAuto = cbLanzAuto
etNotas.setMinLines(4)
etNotas.setGravity(Gravity.TOP)
if repoSel ~= "" then tvRepo.setText("Repositorio: " .. repoSel) end
end
local function mostrarCrearArchivoRepo(alVolver)
local dlg
local ocupado = false
local repoSel = ""
local archivoLocal = ""
local tvRepo, tvArch, etNombre, etContenido, cbReemplazar
local hijos = {
{ TextView, id = "tvArcRepo", text = "Repositorio: ninguno", textColor = "#FFFFFF", textSize = "16sp" },
botonForm("Elegir repositorio", function()
elegirRepositorio(function(nombre)
repoSel = nombre
tvRepo.setText("Repositorio: " .. nombre)
speak("Repositorio " .. nombre)
end)
end),
campo("Nombre del archivo", "etArcNombre", "ejemplo.txt"),
campo("Contenido (si no adjuntas un archivo)", "etArcContenido", "Escribe aquí el contenido"),
{ TextView, id = "tvArcArchivo", text = "Archivo del dispositivo: ninguno", textColor = "#81C784", textSize = "15sp", layout_marginTop = "16dp" },
botonForm("Adjuntar archivo del dispositivo", function()
mostrarExplorador(true, nil, function(lista)
archivoLocal = lista[1] or ""
if archivoLocal ~= "" then
local nom = archivoLocal:match("([^/]+)$") or archivoLocal
tvArch.setText("Archivo del dispositivo: " .. nom)
if recortar(etNombre.getText()) == "" then etNombre.setText(nom) end
speak("Archivo adjuntado: " .. nom)
else
tvArch.setText("Archivo del dispositivo: ninguno")
end
end)
end),
casilla("cbArcReemplazar", "Reemplazar si ya existe"),
}
local function error2(titulo, ok, code, body)
ocupado = false
mostrarError(titulo, ok and explicarErrorGithub(code, body) or tostring(code))
end
local function crear()
if ocupado then return end
if GITHUB_TOKEN == "" then
toast("Primero configura el token")
speak("Primero configura el token")
solicitarTokenDialogo(true)
return
end
if repoSel == "" then
toast("Elige un repositorio")
speak("Elige un repositorio")
return
end
local nombre = recortar(etNombre.getText())
local contenido = tostring(etContenido.getText())
if nombre == "" and archivoLocal ~= "" then
nombre = archivoLocal:match("([^/]+)$") or ""
end
if nombre == "" then
toast("Ingresa el nombre del archivo")
speak("Ingresa el nombre del archivo")
return
end
if archivoLocal == "" and contenido == "" then
toast("Escribe el contenido o adjunta un archivo")
speak("Escribe el contenido o adjunta un archivo")
return
end
if archivoLocal ~= "" then
local tam = File(archivoLocal).length()
if tam > 10 * 1024 * 1024 then
mostrarError("Archivo demasiado grande",
"Este archivo pesa " .. formatearTamano(tam) .. ". Por aquí se admiten hasta 10 MB. Para archivos más pesados usa Crear lanzamiento y adjúntalo allí.")
return
end
end
local rutaRepo = nombre
local mensaje = "Agregar " .. nombre
local reemplazar = cbReemplazar.isChecked()
local urlBase = "https://api.github.com/repos/" .. repoSel .. "/contents/" .. codificarRuta(rutaRepo)
ocupado = true
toast("Preparando archivo...")
speak("Preparando archivo")
task(tareaLeerBase64, archivoLocal, contenido, function(ok, b64)
if not ok then
ocupado = false
mostrarError("No se pudo leer el archivo", tostring(b64))
return
end
task(tareaApi, "GET", urlBase, GITHUB_TOKEN, "", function(ok2, code2, body2)
if not ok2 then
error2("No se pudo consultar el repositorio", ok2, code2, body2)
return
end
local sha = nil
if code2 == 200 then
if not reemplazar then
ocupado = false
mostrarError("El archivo ya existe", "Ya existe '" .. rutaRepo .. "' en el repositorio. Marca 'Reemplazar si ya existe' para sobrescribirlo.")
return
end
sha = tostring(body2):match('"sha"%s*:%s*"([^"]+)"')
elseif code2 ~= 404 then
error2("No se pudo consultar el repositorio", ok2, code2, body2)
return
end
local partes = {
'"message":"' .. jsonEsc(mensaje) .. '"',
'"content":"' .. b64 .. '"',
}
if sha then table.insert(partes, '"sha":"' .. sha .. '"') end
local payload = "{" .. table.concat(partes, ",") .. "}"
toast("Subiendo archivo...")
speak("Subiendo archivo")
task(tareaApi, "PUT", urlBase, GITHUB_TOKEN, payload, function(ok3, code3, body3)
if ok3 and (code3 == 201 or code3 == 200) then
ocupado = false
local enlace = tostring(body3):match('"download_url"%s*:%s*"([^"]+)"')
or tostring(body3):match('"html_url"%s*:%s*"([^"]+)"') or ""
mostrarMensaje("Archivo guardado", enlace, function()
dlg.dismiss()
alVolver()
end)
else
error2("No se pudo guardar el archivo", ok3, code3, body3)
end
end)
end)
end)
end
dlg = mostrarPantallaForm("Crear archivo", hijos, "Crear",
function() crear() end,
function(d) d.dismiss() alVolver() end)
tvRepo = tvArcRepo
tvArch = tvArcArchivo
etNombre = etArcNombre
etContenido = etArcContenido
cbReemplazar = cbArcReemplazar
etContenido.setMinLines(5)
etContenido.setGravity(Gravity.TOP)
end
local function copiarAlPortapapeles(texto)
local ok = false
if service and service.copy then
ok = pcall(function() service.copy(texto) end)
end
if not ok then
ok = pcall(function()
local cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE)
local ClipData = luajava.bindClass("android.content.ClipData")
cm.setPrimaryClip(ClipData.newPlainText("enlace", texto))
end)
end
if ok then
toast("Enlace copiado")
speak("Enlace copiado")
else
toast("No se pudo copiar el enlace")
speak("No se pudo copiar el enlace")
end
end
local function parsearLanzamientos(body)
local res = {}
local posiciones = {}
local pos = 1
while true do
local ini, fin, id = body:find('"url"%s*:%s*"https://api%.github%.com/repos/[^"/]+/[^"/]+/releases/(%d+)"', pos)
if not ini then break end
table.insert(posiciones, { ini = ini, id = id })
pos = fin + 1
end
for k, p in ipairs(posiciones) do
local fin = #body
if posiciones[k + 1] then fin = posiciones[k + 1].ini - 1 end
local trozo = body:sub(p.ini, fin)
local html = trozo:match('"html_url"%s*:%s*"([^"]+)"') or ""
local tag = trozo:match('"tag_name"%s*:%s*"([^"]*)"') or ""
local nombre = trozo:match('"tag_name"%s*:%s*"[^"]*"[^{}]-"name"%s*:%s*"([^"]*)"')
if not nombre or nombre == "" then nombre = tag end
local assets = {}
for u in trozo:gmatch('"browser_download_url"%s*:%s*"([^"]+)"') do
table.insert(assets, u)
end
table.insert(res, { id = p.id, html = html, tag = tag, nombre = nombre, assets = assets })
end
return res
end
local function mostrarDetalleRemoto(titulo, enlace, textoEliminar, mensajeConfirmar, accionEliminar, alTerminar, accionVer)
local dlg
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", padding = "16dp", background = "#0D0D1A",
{ TextView, text = titulo, textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingBottom = "20dp" },
{ Button, text = "Copiar enlace", textSize = "16sp", textColor = "#FFFFFF", background = "#1E1E2E", layout_width = "match_parent", layout_marginBottom = "12dp",
onClick = function()
vibrar()
if type(enlace) == "function" then
enlace()
else
copiarAlPortapapeles(enlace)
end
end },
{ Button, text = textoEliminar, textSize = "16sp", textColor = "#FFFFFF", background = "#6B1A1A", layout_width = "match_parent",
onClick = function()
vibrar()
confirmarEliminar(mensajeConfirmar, function()
accionEliminar(function()
dlg.dismiss()
alTerminar(true)
end)
end)
end },
{ LinearLayout, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1" },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "right",
{ Button, text = "Cerrar", textColor = "#FFFFFF", background = "#3D3D6B",
onClick = function()
vibrar()
dlg.dismiss()
alTerminar(false)
end },
}
}
if accionVer then
table.insert(layout, 3, {
Button, text = "Ver contenido", textSize = "16sp", textColor = "#FFFFFF", background = "#1E1E2E", layout_width = "match_parent", layout_marginBottom = "12dp",
onClick = function()
vibrar()
accionVer()
end
})
end
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
speak(titulo)
end
local function mostrarAdminRepositorios(alVolver, datosCache, esActualizacion)
local function mostrarLista(nombres)
local dlg
local items = {}
for _, n in ipairs(nombres) do
local nombreRepo = n
table.insert(items, {
texto = nombreRepo,
onClick = function()
dlg.dismiss()
mostrarDetalleRemoto(
nombreRepo,
"https://github.com/" .. nombreRepo,
"Eliminar repositorio",
"¿Eliminar definitivamente el repositorio \"" .. nombreRepo .. "\"? Esta acción no se puede deshacer.",
function(exito)
toast("Eliminando repositorio...")
speak("Eliminando repositorio")
task(tareaApi, "DELETE", "https://api.github.com/repos/" .. nombreRepo, GITHUB_TOKEN, "", function(ok, code, body)
if ok and code == 204 then
toast("Repositorio eliminado")
speak("Repositorio eliminado")
exito()
else
local extra = ""
if code == 403 then extra = "\n\nPara eliminar repositorios el token necesita el permiso delete_repo." end
mostrarError("No se pudo eliminar el repositorio", explicarErrorGithub(code, body) .. extra)
end
end)
end,
function(cambio)
if cambio then
mostrarAdminRepositorios(alVolver, nil, true)
else
mostrarAdminRepositorios(alVolver, nombres)
end
end
)
end
})
end
dlg = pantallaLista({
titulo = "Mis repositorios",
items = items,
vacio = "Todavía no tienes repositorios.",
onVolver = function()
dlg.dismiss()
alVolver()
end
})
end
if datosCache then
mostrarLista(datosCache)
return
end
local mensaje = "Cargando repositorios"
if esActualizacion then mensaje = "Actualizando repositorios" end
obtenerRepositorios(function(nombres)
if not nombres then
alVolver()
return
end
mostrarLista(nombres)
end, mensaje)
end
local function obtenerTodosLosLanzamientos(callback, mensaje)
obtenerRepositorios(function(nombres)
if not nombres then
callback(nil)
return
end
local todos = {}
local total = #nombres
if total == 0 then
callback(todos)
return
end
local siguiente = 1
local terminados = 0
local lanzarSiguiente
lanzarSiguiente = function()
if siguiente > total then return end
local repo = nombres[siguiente]
siguiente = siguiente + 1
task(tareaApi, "GET", "https://api.github.com/repos/" .. repo .. "/releases?per_page=100", GITHUB_TOKEN, "", function(ok, code, body)
if ok and code == 200 then
for _, l in ipairs(parsearLanzamientos(tostring(body))) do
l.repo = repo
table.insert(todos, l)
end
end
terminados = terminados + 1
if terminados == total then
callback(todos)
else
lanzarSiguiente()
end
end)
end
for _ = 1, math.min(6, total) do
lanzarSiguiente()
end
end, mensaje)
end
local function mostrarAdminLanzamientos(alVolver, datosCache, esActualizacion)
local function mostrarLista(lista)
local dlg
local items = {}
for _, l in ipairs(lista) do
local lanz = l
local texto = lanz.nombre
if lanz.tag ~= "" and lanz.tag ~= lanz.nombre then
texto = texto .. " (" .. lanz.tag .. ")"
end
texto = texto .. "\nRepositorio: " .. lanz.repo
table.insert(items, {
texto = texto,
onClick = function()
dlg.dismiss()
mostrarDetalleRemoto(
lanz.nombre,
function()
if #lanz.assets == 0 then
toast("Este lanzamiento no tiene archivos adjuntos. Se copió el enlace de su página.")
speak("Este lanzamiento no tiene archivos adjuntos. Se copió el enlace de su página.")
copiarAlPortapapeles(lanz.html)
elseif #lanz.assets == 1 then
copiarAlPortapapeles(lanz.assets[1])
else
local dlgA
local itemsA = {}
for _, url in ipairs(lanz.assets) do
local enlaceArchivo = url
table.insert(itemsA, {
texto = enlaceArchivo:match("([^/]+)$") or enlaceArchivo,
onClick = function()
dlgA.dismiss()
copiarAlPortapapeles(enlaceArchivo)
end
})
end
dlgA = pantallaLista({
titulo = "Elige el archivo",
subtitulo = "Se copiará su enlace de descarga",
items = itemsA,
onVolver = function() dlgA.dismiss() end
})
end
end,
"Eliminar lanzamiento",
"¿Eliminar el lanzamiento \"" .. lanz.nombre .. "\"?",
function(exito)
toast("Eliminando lanzamiento...")
speak("Eliminando lanzamiento")
task(tareaApi, "DELETE", "https://api.github.com/repos/" .. lanz.repo .. "/releases/" .. lanz.id, GITHUB_TOKEN, "", function(ok2, code2, body2)
if ok2 and code2 == 204 then
toast("Lanzamiento eliminado")
speak("Lanzamiento eliminado")
exito()
else
mostrarError("No se pudo eliminar el lanzamiento", explicarErrorGithub(code2, body2))
end
end)
end,
function(cambio)
if cambio then
mostrarAdminLanzamientos(alVolver, nil, true)
else
mostrarAdminLanzamientos(alVolver, lista)
end
end
)
end
})
end
dlg = pantallaLista({
titulo = "Mis lanzamientos",
items = items,
vacio = "Todavía no tienes lanzamientos creados.",
onVolver = function()
dlg.dismiss()
alVolver()
end
})
end
if datosCache then
mostrarLista(datosCache)
return
end
local mensaje = "Cargando lanzamientos"
if esActualizacion then mensaje = "Actualizando lanzamientos" end
obtenerTodosLosLanzamientos(function(lista)
if not lista then
alVolver()
return
end
mostrarLista(lista)
end, mensaje)
end
local function cargarArchivosCreados(callback, mensaje)
obtenerRepositorios(function(nombres)
if not nombres then
callback(nil)
return
end
local total = #nombres
if total == 0 then
callback({})
return
end
local resultados = {}
local siguiente = 1
local terminados = 0
local lanzar
lanzar = function()
if siguiente > total then return end
local idx = siguiente
siguiente = siguiente + 1
local repo = nombres[idx]
local url = "https://api.github.com/repos/" .. repo .. "/git/trees/HEAD?recursive=1"
task(tareaApi, "GET", url, GITHUB_TOKEN, "", function(ok, code, body)
local lista = {}
if ok and code == 200 then
local patron = '"path"%s*:%s*"([^"]+)"[^{}]-"type"%s*:%s*"blob"[^{}]-"sha"%s*:%s*"([^"]+)"'
for ruta, sha in tostring(body):gmatch(patron) do
table.insert(lista, {
repo = repo,
ruta = ruta,
sha = sha,
url = "https://raw.githubusercontent.com/" .. repo .. "/HEAD/" .. codificarRuta(ruta)
})
end
end
resultados[idx] = lista
terminados = terminados + 1
if terminados == total then
local todos = {}
for i = 1, total do
for _, a in ipairs(resultados[i] or {}) do
table.insert(todos, a)
end
end
callback(todos)
else
lanzar()
end
end)
end
for _ = 1, math.min(6, total) do
lanzar()
end
end, mensaje)
end
local function mostrarAdminArchivos(alVolver, datosCache, esActualizacion)
local function mostrarLista(lista)
local dlg
local items = {}
for _, a in ipairs(lista) do
local arch = a
local nombre = arch.ruta:match("([^/]+)$") or arch.ruta
table.insert(items, {
texto = arch.ruta .. "\nRepositorio: " .. arch.repo,
onClick = function()
dlg.dismiss()
local urlContenido = "https://api.github.com/repos/" .. arch.repo .. "/contents/" .. codificarRuta(arch.ruta)
mostrarDetalleRemoto(
nombre,
function()
local enlace = arch.url
if enlace == "" then
enlace = "https://github.com/" .. arch.repo .. "/blob/HEAD/" .. arch.ruta
end
copiarAlPortapapeles(enlace)
end,
"Eliminar archivo",
"¿Eliminar el archivo \"" .. nombre .. "\" del repositorio?",
function(exito)
toast("Eliminando archivo...")
speak("Eliminando archivo")
task(tareaApi, "GET", urlContenido, GITHUB_TOKEN, "", function(ok, code, body)
if ok and code == 404 then
toast("El archivo ya no existe")
exito()
return
end
local sha = nil
if ok and code == 200 then
sha = tostring(body):match('"sha"%s*:%s*"([^"]+)"')
end
if not sha then
mostrarError("No se pudo eliminar el archivo", explicarErrorGithub(code, body))
return
end
local payload = '{"message":"' .. jsonEsc("Eliminar " .. nombre) .. '","sha":"' .. sha .. '"}'
task(tareaApi, "DELETE", urlContenido, GITHUB_TOKEN, payload, function(ok2, code2, body2)
if ok2 and code2 == 200 then
toast("Archivo eliminado")
speak("Archivo eliminado")
exito()
else
mostrarError("No se pudo eliminar el archivo", explicarErrorGithub(code2, body2))
end
end)
end)
end,
function(cambio)
if cambio then
mostrarAdminArchivos(alVolver, nil, true)
else
mostrarAdminArchivos(alVolver, lista)
end
end
)
end
})
end
dlg = pantallaLista({
titulo = "Mis archivos",
items = items,
vacio = "No se encontraron archivos en tus repositorios.",
onVolver = function()
dlg.dismiss()
alVolver()
end
})
end
if datosCache then
mostrarLista(datosCache)
return
end
local mensaje = "Cargando archivos"
if esActualizacion then mensaje = "Actualizando archivos" end
cargarArchivosCreados(function(lista)
if not lista then
alVolver()
return
end
mostrarLista(lista)
end, mensaje)
end
local function parsearGists(body)
local res = {}
local posiciones = {}
local pos = 1
while true do
local ini, fin, id = body:find('"url"%s*:%s*"https://api%.github%.com/gists/(%w+)"', pos)
if not ini then break end
table.insert(posiciones, { ini = ini, id = id })
pos = fin + 1
end
for k, p in ipairs(posiciones) do
local fin = #body
if posiciones[k + 1] then fin = posiciones[k + 1].ini - 1 end
local trozo = body:sub(p.ini, fin)
local html = trozo:match('"html_url"%s*:%s*"([^"]+)"') or ""
local owner = html:match("gist%.github%.com/([^/]+)/") or ""
local archivos = {}
for nombre, raw in trozo:gmatch('"filename"%s*:%s*"([^"]+)"[^{}]-"raw_url"%s*:%s*"([^"]+)"') do
table.insert(archivos, { nombre = nombre, raw = raw })
end
local desc = trozo:match('"description"%s*:%s*"([^"]*)"') or ""
local publico = trozo:match('"public"%s*:%s*(%a+)') == "true"
table.insert(res, { id = p.id, html = html, owner = owner, archivos = archivos, desc = desc, publico = publico })
end
return res
end
local function obtenerGists(callback, mensaje)
if GITHUB_TOKEN == "" then
toast("Primero configura el token")
speak("Primero configura el token")
solicitarTokenDialogo(true)
callback(nil)
return
end
mensaje = mensaje or "Cargando archivos gist"
toast(mensaje)
speak(mensaje)
local todos = {}
local function pagina(n)
task(tareaApi, "GET", "https://api.github.com/gists?per_page=100&page=" .. n, GITHUB_TOKEN, "", function(ok, code, body)
if not (ok and code == 200) then
mostrarError("No se pudieron cargar los archivos gist", explicarErrorGithub(code, body))
callback(nil)
return
end
local lista = parsearGists(tostring(body))
for _, g in ipairs(lista) do table.insert(todos, g) end
if #lista >= 100 and n < 5 then
pagina(n + 1)
else
callback(todos)
end
end)
end
pagina(1)
end
local function mostrarContenido(titulo, texto)
local dlg
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#0D0D1A",
{ TextView, text = titulo, textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingTop = "16dp", paddingBottom = "16dp", layout_width = "match_parent", background = "#1A1A2E" },
{ ScrollView, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1",
{ TextView, text = texto, textSize = "15sp", textColor = "#FFFFFF", padding = "16dp", layout_width = "match_parent" } },
{ LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "right", padding = "12dp", background = "#1A1A2E",
{ Button, text = "Cerrar", textColor = "#FFFFFF", background = "#3D3D6B",
onClick = function()
vibrar()
dlg.dismiss()
end } },
}
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
speak(titulo)
end
local function mostrarCrearGist(alVolver)
local dlg
local ocupado = false
local publico = false
local etDesc, etNombre, etContenido, btnVis
local function textoVis()
if publico then return "Visibilidad: Público (toca para cambiar)" end
return "Visibilidad: Secreto (toca para cambiar)"
end
local hijos = {
campo("Descripción (opcional)", "etGistDesc", "Descripción corta"),
campo("Nombre del archivo", "etGistNombre", "ejemplo.txt"),
campo("Contenido", "etGistContenido", "Escribe aquí el contenido"),
{
Button, id = "btnGistVis", text = textoVis(), textSize = "15sp", textColor = "#FFFFFF", background = "#1E1E2E",
layout_width = "match_parent", layout_marginTop = "16dp",
onClick = function()
vibrar()
publico = not publico
btnVis.setText(textoVis())
if publico then speak("Público") else speak("Secreto") end
end
},
}
local function crear()
if ocupado then return end
if GITHUB_TOKEN == "" then
toast("Primero configura el token")
speak("Primero configura el token")
solicitarTokenDialogo(true)
return
end
local nombre = recortar(etNombre.getText())
local contenido = tostring(etContenido.getText())
local desc = recortar(etDesc.getText())
if nombre == "" then
toast("Ingresa el nombre del archivo")
speak("Ingresa el nombre del archivo")
return
end
if recortar(contenido) == "" then
toast("Escribe el contenido del archivo")
speak("Escribe el contenido del archivo")
return
end
local payload = '{"description":"' .. jsonEsc(desc) .. '","public":' .. tostring(publico) ..
',"files":{"' .. jsonEsc(nombre) .. '":{"content":"' .. jsonEsc(contenido) .. '"}}}'
ocupado = true
toast("Creando archivo gist...")
speak("Creando archivo gist")
task(tareaApi, "POST", "https://api.github.com/gists", GITHUB_TOKEN, payload, function(ok, code, body)
ocupado = false
if ok and code == 201 then
local g = parsearGists(tostring(body))[1]
local enlace = ""
if g and g.owner ~= "" then
enlace = "https://gist.githubusercontent.com/" .. g.owner .. "/" .. g.id .. "/raw/" .. codificarComponente(nombre)
elseif g then
enlace = g.html
end
mostrarMensaje("Archivo gist creado", enlace, function()
dlg.dismiss()
alVolver()
end)
else
mostrarError("No se pudo crear el archivo gist", explicarErrorGithub(code, body))
end
end)
end
dlg = mostrarPantallaForm("Crear archivo gist", hijos, "Crear",
function() crear() end,
function(d) d.dismiss() alVolver() end)
etDesc = etGistDesc
etNombre = etGistNombre
etContenido = etGistContenido
btnVis = btnGistVis
etContenido.setMinLines(5)
etContenido.setGravity(Gravity.TOP)
end
local function conArchivoGist(g, fn)
if #g.archivos == 0 then
toast("Este gist no tiene archivos")
speak("Este gist no tiene archivos")
elseif #g.archivos == 1 then
fn(g.archivos[1])
else
local dlgA
local itemsA = {}
for _, a in ipairs(g.archivos) do
local arch = a
table.insert(itemsA, {
texto = arch.nombre,
onClick = function()
dlgA.dismiss()
fn(arch)
end
})
end
dlgA = pantallaLista({
titulo = "Elige el archivo",
items = itemsA,
onVolver = function() dlgA.dismiss() end
})
end
end
local function mostrarAdminGists(alVolver, datosCache, esActualizacion)
local function mostrarLista(lista)
local dlg
local items = {}
for _, gi in ipairs(lista) do
local g = gi
local titulo = g.id
if #g.archivos > 0 then titulo = g.archivos[1].nombre end
local texto = titulo
if #g.archivos > 1 then texto = texto .. " y " .. (#g.archivos - 1) .. " más" end
if g.publico then texto = texto .. "\nPúblico" else texto = texto .. "\nSecreto" end
if g.desc ~= "" then texto = texto .. " - " .. g.desc end
if g.id == GIST_ID then texto = texto .. " (base de datos del complemento)" end
table.insert(items, {
texto = texto,
onClick = function()
dlg.dismiss()
mostrarDetalleRemoto(
titulo,
function()
conArchivoGist(g, function(a)
local enlace = a.raw
if g.owner ~= "" then
enlace = "https://gist.githubusercontent.com/" .. g.owner .. "/" .. g.id .. "/raw/" .. codificarComponente(a.nombre)
end
copiarAlPortapapeles(enlace)
end)
end,
"Eliminar gist",
"¿Eliminar el gist \"" .. titulo .. "\"? Esta acción no se puede deshacer.",
function(exito)
if g.id == GIST_ID then
mostrarError("No se puede eliminar", "Este gist guarda la lista de carpetas y capítulos del complemento. Si lo eliminas, el complemento dejaría de funcionar.")
return
end
toast("Eliminando archivo gist...")
speak("Eliminando archivo gist")
task(tareaApi, "DELETE", "https://api.github.com/gists/" .. g.id, GITHUB_TOKEN, "", function(ok, code, body)
if ok and code == 204 then
toast("Archivo gist eliminado")
speak("Archivo gist eliminado")
exito()
else
mostrarError("No se pudo eliminar el archivo gist", explicarErrorGithub(code, body))
end
end)
end,
function(cambio)
if cambio then
mostrarAdminGists(alVolver, nil, true)
else
mostrarAdminGists(alVolver, lista)
end
end,
function()
conArchivoGist(g, function(a)
toast("Cargando contenido...")
speak("Cargando contenido")
task(tareaApi, "GET", a.raw, GITHUB_TOKEN, "", function(ok, code, body)
if ok and code == 200 then
local t = tostring(body)
if t == "" then t = "(archivo vacío)" end
if #t > 20000 then t = t:sub(1, 20000) .. "\n\n[Contenido recortado]" end
mostrarContenido(a.nombre, t)
else
mostrarError("No se pudo cargar el contenido", explicarErrorGithub(code, body))
end
end)
end)
end
)
end
})
end
dlg = pantallaLista({
titulo = "Mis archivos gist",
items = items,
vacio = "Todavía no tienes archivos gist.",
onVolver = function()
dlg.dismiss()
alVolver()
end
})
end
if datosCache then
mostrarLista(datosCache)
return
end
local mensaje = "Cargando archivos gist"
if esActualizacion then mensaje = "Actualizando archivos gist" end
obtenerGists(function(lista)
if not lista then
alVolver()
return
end
mostrarLista(lista)
end, mensaje)
end
local function mostrarConfiguracion()
local dlg
local function volverAqui()
dlg.show()
end
local function boton(texto, fn)
return {
Button, text = texto, textSize = "16sp", textColor = "#FFFFFF", background = "#1E1E2E",
layout_width = "match_parent", layout_marginBottom = "12dp",
onClick = function()
vibrar()
dlg.hide()
fn()
end
}
end
local layout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#0D0D1A",
{ TextView, text = "Configuraciones", textSize = "20sp", textColor = "#FFFFFF", gravity = "center", paddingTop = "16dp", paddingBottom = "16dp", layout_width = "match_parent", background = "#1A1A2E" },
{
ScrollView, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1",
{
LinearLayout, orientation = "vertical", layout_width = "match_parent", padding = "16dp",
boton("Configurar token", function() solicitarTokenDialogo(true, dlg) end),
boton("Crear archivo gist", function() mostrarCrearGist(volverAqui) end),
boton("Crear repositorio", function() mostrarCrearRepositorio(volverAqui) end),
boton("Crear lanzamiento", function() mostrarCrearLanzamiento(volverAqui) end),
boton("Crear archivo", function() mostrarCrearArchivoRepo(volverAqui) end),
boton("Repositorios creados", function() mostrarAdminRepositorios(volverAqui) end),
boton("Lanzamientos creados", function() mostrarAdminLanzamientos(volverAqui) end),
boton("Archivos creados", function() mostrarAdminArchivos(volverAqui) end),
boton("Mis archivos gist", function() mostrarAdminGists(volverAqui) end),
boton("Gestionar archivos por carpetas", function() mostrarAdminCarpetas(volverAqui) end),
boton("Gestionar archivos individuales", function() mostrarAdminIndividuales(volverAqui) end),
boton("Filtro de archivo", function() mostrarFiltro(volverAqui) end),
},
},
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "right", padding = "12dp", background = "#1A1A2E",
{ Button, text = "Cerrar", textColor = "#FFFFFF", background = "#3D3D6B",
onClick = function()
vibrar()
dlg.dismiss()
sincronizarDesdeGitHub(function()
mostrarMenuPrincipal()
end)
end },
}
}
dlg = LuaDialog(ctx)
dlg.setView(loadlayout(layout))
dlg.setCancelable(false)
dlg.show()
speak("Configuraciones")
end
mostrarSerie = function(serie, mainDlg)
local serieDlg
local caps = serie.capitulos
local scrollContent = {
LinearLayout, orientation = "vertical", layout_width = "match_parent",
paddingLeft = "16dp", paddingRight = "16dp", paddingTop = "8dp", paddingBottom = "80dp",
}
if #caps == 0 then
table.insert(scrollContent, { TextView, text = "Esta carpeta todavía no tiene capítulos.", textColor = "#AAAAAA", textSize = "16sp", padding = "12dp" })
end
for i, cap in ipairs(caps) do
local capData = cap
local capIndex = i
local tvId = "tvCap_" .. i
local tipo = obtenerTipoArchivo(capData.githubUrl)
table.insert(scrollContent, {
TextView, id = tvId, text = textoConTipo(cap.nombre, cap.githubUrl), textSize = "17sp", textColor = "#FFFFFF",
paddingTop = "16dp", paddingBottom = "6dp", paddingLeft = "8dp", paddingRight = "8dp",
layout_width = "match_parent", background = "#1E1E2E",
onClick = function()
vibrar()
speak(capData.nombre)
if tipo == "video" then
reproducirVideoInterno(caps, capIndex)
elseif tipo == "audio" then
reproducirAudioConControles(caps, capIndex)
else
toast("Este archivo no se puede reproducir internamente")
end
end,
})
table.insert(scrollContent, {
Button, text = "Descargar", textSize = "14sp", layout_width = "match_parent",
layout_marginTop = "2dp", layout_marginBottom = "12dp", background = "#16213E", textColor = "#FFB74D",
onClick = function()
vibrar()
descargarArchivoLocal(capData.nombre, capData.githubUrl)
end
})
table.insert(scrollContent, {
View, layout_width = "match_parent", layout_height = "1dp", background = "#333355"
})
end
local serieLayout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#0D0D1A",
{ TextView, text = serie.titulo, textSize = "22sp", textColor = "#FFFFFF", gravity = "center", paddingTop = "16dp", paddingBottom = "16dp", layout_width = "match_parent", background = "#1A1A2E" },
{ ScrollView, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1", scrollContent },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "right", padding = "12dp", background = "#1A1A2E",
{ Button, text = "Volver", textSize = "15sp", textColor = "#FFFFFF", background = "#3D3D6B", paddingLeft = "20dp", paddingRight = "20dp",
onClick = function()
vibrar()
serieDlg.dismiss()
task(150, function() mainDlg.show() end)
end },
},
}
serieDlg = LuaDialog(ctx)
serieDlg.setView(loadlayout(serieLayout))
serieDlg.setCancelable(false)
serieDlg.show()
speak(serie.titulo)
end
mostrarMenuPrincipal = function()
local mainDlg
local mostrarCarpetas = (FILTRO == "todos" or FILTRO == "carpetas")
local individualesVisibles = {}
if FILTRO == "todos" or FILTRO == "individuales" then
individualesVisibles = INDIVIDUALES
end
local seriesContent = {
LinearLayout, orientation = "vertical", layout_width = "match_parent",
paddingLeft = "16dp", paddingRight = "16dp", paddingTop = "8dp", paddingBottom = "80dp",
}
for i, serie in ipairs(SERIES) do
if not mostrarCarpetas then break end
local serieData = serie
local tvId = "tvSerie_" .. i
table.insert(seriesContent, {
TextView, id = tvId, text = "Carpeta: " .. serieData.titulo, textSize = "20sp", textColor = "#FFFFFF",
paddingTop = "18dp", paddingBottom = "18dp", paddingLeft = "16dp", paddingRight = "16dp",
layout_width = "match_parent", layout_marginBottom = "10dp", background = "#1E1E2E",
onClick = function()
vibrar()
mainDlg.hide()
task(150, function() mostrarSerie(serieData, mainDlg) end)
end,
})
end
if #individualesVisibles > 0 then
for i, cap in ipairs(individualesVisibles) do
local capData = cap
local capIndex = i
local tvId = "tvInd_" .. i
local tipo = obtenerTipoArchivo(capData.githubUrl)
table.insert(seriesContent, {
TextView, id = tvId, text = textoConTipo(capData.nombre, capData.githubUrl), textSize = "17sp", textColor = "#FFFFFF",
paddingTop = "16dp", paddingBottom = "6dp", paddingLeft = "8dp", paddingRight = "8dp",
layout_width = "match_parent", background = "#1E1E2E",
onClick = function()
vibrar()
speak(capData.nombre)
if tipo == "video" then
reproducirVideoInterno(individualesVisibles, capIndex)
elseif tipo == "audio" then
reproducirAudioConControles(individualesVisibles, capIndex)
else
toast("Este archivo no se puede reproducir internamente")
end
end,
})
table.insert(seriesContent, {
Button, text = "Descargar", textSize = "14sp", layout_width = "match_parent",
layout_marginTop = "2dp", layout_marginBottom = "12dp", background = "#16213E", textColor = "#FFB74D",
onClick = function()
vibrar()
descargarArchivoLocal(capData.nombre, capData.githubUrl)
end
})
table.insert(seriesContent, {
View, layout_width = "match_parent", layout_height = "1dp", background = "#333355"
})
end
end
if (not mostrarCarpetas or #SERIES == 0) and #individualesVisibles == 0 then
table.insert(seriesContent, {
TextView, text = "No hay carpetas ni archivos para mostrar. Usa Ajustes para crearlos.",
textColor = "#AAAAAA", textSize = "16sp", padding = "12dp"
})
end
local mainLayout = {
LinearLayout, orientation = "vertical", layout_width = "match_parent", layout_height = "match_parent", background = "#0D0D1A",
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", background = "#1A1A2E",
paddingTop = "20dp", paddingBottom = "20dp", paddingLeft = "16dp", paddingRight = "8dp", gravity = "center_vertical",
{ TextView, text = "Administrador de archivos GitHub", textSize = "22sp", textColor = "#FFFFFF", layout_width = "0dp", layout_weight = "1" },
{ Button, text = "Configuración", textSize = "12sp", textColor = "#FFFFFF", background = "#4A4A4A",
onClick = function()
vibrar()
mainDlg.dismiss()
mostrarConfiguracion()
end },
},
{ ScrollView, layout_width = "match_parent", layout_height = "0dp", layout_weight = "1", seriesContent },
{
LinearLayout, orientation = "horizontal", layout_width = "match_parent", gravity = "center", padding = "8dp", background = "#1A1A2E",
{ Button, text = "Cerrar", textSize = "13sp", textColor = "#FFFFFF", background = "#6B1A1A", layout_width = "match_parent",
onClick = function()
vibrar()
mainDlg.dismiss()
cerrarComplemento()
end },
},
}
mainDlg = LuaDialog(ctx)
mainDlg.setView(loadlayout(mainLayout))
mainDlg.setCancelable(false)
mainDlg.show()
end
iniciarFlujoPrincipal = function()
sincronizarDesdeGitHub(function()
mostrarMenuPrincipal()
end)
end
GITHUB_TOKEN = obtenerTokenGuardado()
FILTRO = obtenerFiltroGuardado()
if GITHUB_TOKEN == "" then
solicitarTokenDialogo(false)
else
iniciarFlujoPrincipal()
end